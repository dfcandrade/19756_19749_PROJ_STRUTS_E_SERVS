package teste;

import junit.framework.TestCase;

public class Teste2 extends TestCase {

    public void testHello2()
    {
        assertEquals("Hello Student","Hello Student");

        //fail("FALHA PROPOSITADA");


    }
}
