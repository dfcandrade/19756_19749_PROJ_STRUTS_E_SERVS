package teste.web;

import javax.servlet.*;
import java.io.IOException;

public abstract class CetificateFilter implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

    }
}
