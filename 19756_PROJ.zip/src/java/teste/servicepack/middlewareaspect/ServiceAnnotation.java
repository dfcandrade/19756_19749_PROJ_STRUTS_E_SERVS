package teste.servicepack.middlewareaspect;

/**
 * Created by jorgemachado on 18/10/18.
 */
public @interface ServiceAnnotation {
}
