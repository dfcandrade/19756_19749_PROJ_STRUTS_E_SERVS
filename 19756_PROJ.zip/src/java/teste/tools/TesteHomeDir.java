package teste.tools;

public class TesteHomeDir {

    public static void main(String[] args)
    {

        System.out.println(System.getProperty("user.home") + "\\Local Settings\\Application Data");

        
    }
}
