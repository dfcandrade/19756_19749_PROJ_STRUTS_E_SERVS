package teste.servicepack.security.logic;

public @interface CriadorPagina {

}
