package teste.servicepack.security.logic;

public @interface injectSession {
}
