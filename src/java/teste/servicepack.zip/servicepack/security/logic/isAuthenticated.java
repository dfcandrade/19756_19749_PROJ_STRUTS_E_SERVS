package teste.servicepack.security.logic;

public @interface isAuthenticated {
}
