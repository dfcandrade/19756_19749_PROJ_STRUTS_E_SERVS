package teste.servicepack.security.logic;

public @interface Transaction {
}
